# 💼 Smart Salary Predictor using Ensemble Learning

This project predicts salaries based on education, experience, role, and age using Random Forest, Gradient Boosting, and Stacking Regressor.

## 🔧 Technologies
- Python
- scikit-learn
- Flask (for API)
- pandas, numpy

## 🚀 How to Run

1. `python main.py` to train and save the model  
2. `python api.py` to start Flask server  
3. Send POST request to `/predict`

## 📁 Files
- `main.py`: Model training
- `api.py`: API endpoint
- `stack_model.pkl`: Trained model
- `label_encoders.pkl`: Encoders
