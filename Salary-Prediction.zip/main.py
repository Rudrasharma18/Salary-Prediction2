import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, StackingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error
import pickle

data = {
    'Education': np.random.choice(['Bachelors', 'Masters', 'PhD'], 100),
    'Experience': np.random.randint(0, 15, 100),
    'City': np.random.choice(['Mumbai', 'Delhi', 'Bangalore'], 100),
    'Role': np.random.choice(['Developer', 'Analyst', 'Manager'], 100),
    'Age': np.random.randint(22, 50, 100),
}
df = pd.DataFrame(data)
base_salary = 20000 + df['Experience'] * 1500 + df['Age'] * 100
role_bonus = {'Developer': 5000, 'Analyst': 3000, 'Manager': 8000}
df['Salary'] = base_salary + df['Role'].map(role_bonus) + np.random.randint(-3000, 3000, 100)

label_encoders = {}
for col in ['Education', 'City', 'Role']:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

X = df.drop('Salary', axis=1)
y = df['Salary']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

rf = RandomForestRegressor(n_estimators=100, random_state=42)
gb = GradientBoostingRegressor(n_estimators=100, random_state=42)
stack = StackingRegressor(estimators=[('rf', rf), ('gb', gb)], final_estimator=Ridge())
stack.fit(X_train, y_train)

pred = stack.predict(X_test)
print("MSE:", mean_squared_error(y_test, pred))

with open("stack_model.pkl", "wb") as f:
    pickle.dump(stack, f)
with open("label_encoders.pkl", "wb") as f:
    pickle.dump(label_encoders, f)
