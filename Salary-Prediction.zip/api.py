from flask import Flask, request, jsonify
import pickle
import pandas as pd

model = pickle.load(open("stack_model.pkl", "rb"))
label_encoders = pickle.load(open("label_encoders.pkl", "rb"))

app = Flask(__name__)

@app.route('/')
def home():
    return "Salary Predictor API is running."

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    try:
        input_data = pd.DataFrame([{
            "Education": label_encoders['Education'].transform([data['Education']])[0],
            "Experience": data['Experience'],
            "City": label_encoders['City'].transform([data['City']])[0],
            "Role": label_encoders['Role'].transform([data['Role']])[0],
            "Age": data['Age']
        }])
        prediction = model.predict(input_data)[0]
        return jsonify({"predicted_salary": round(prediction, 2)})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(port=8501)
